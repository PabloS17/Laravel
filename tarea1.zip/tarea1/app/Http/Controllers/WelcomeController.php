<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Cuenta;


class WelcomeController extends Controller
{
    //
    public function welcome($username)
{
    $user = Cuenta::where('NombreUsuario', $username)->first();
    $numLogins = $user->Logeos;

    return view('welcome', ['username' => $username, 'numLogins' => $numLogins]);
}
}
