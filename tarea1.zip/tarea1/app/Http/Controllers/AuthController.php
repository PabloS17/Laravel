<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
use App\Cuenta;

class AuthController extends Controller
{
    public function store(Request $request)
    {
        $request->validate([
            'NombreUsuario' => 'required|unique:Cuenta',
            'Contrasena' => 'required|min:6'
        ]);

        $cuenta = new Cuenta;
        $cuenta->NombreUsuario = $request->input('NombreUsuario');
        $cuenta->Contrasena = Hash::make($request->input('Contrasena'));
        //$cuenta->Contrasena = $request->input('Contrasena');
        $cuenta->save();

        return redirect('/login')->with('success', 'Your account has been created.');
    }
}
