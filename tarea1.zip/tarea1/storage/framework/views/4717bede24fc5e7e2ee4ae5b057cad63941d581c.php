<!DOCTYPE html>
<html>
<head>
    <title>Bienvenido</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
</head>
<body style="Background-color:SlateGray;">
    <div class="container" style="Color:white;" align="center">
        
        <FONT FACE="cursive" SIZE=10 COLOR="white"> Bienvenido, <?php echo e($username ?? ''); ?>!</FONT>
        <p>Has iniciado sesión <?php echo e($numLogins ?? ''); ?> veces.</p>
        <img src="https://media.tenor.com/uaQMpccz_yYAAAAd/out-west-travis-scott.gif">
    </div>
</body>
</html>

<?php /**PATH /home/pablo17/Documents/Diseno/tarea1/resources/views/welcome.blade.php ENDPATH**/ ?>